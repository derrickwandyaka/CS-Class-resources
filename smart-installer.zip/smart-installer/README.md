# Smart Installer (MVP scaffold)

Type what software you need, it finds a match in the catalog and installs it.
Offline mode scans your Downloads/Desktop for installers already on disk.

## How it works

- `catalog/apps.json` — the "brain." A hand-curated list of apps with keywords,
  official download URLs, and silent-install flags. This is your keyword-matching
  version of the "AI guesser." Swap `src/matcher.js` for an LLM API call later
  without touching anything else.
- `src/matcher.js` — scores catalog entries against user input (exact + fuzzy word match).
- `src/installer.js` — downloads installers from official URLs and runs them with
  silent flags. Also scans local folders for offline mode.
- `src/main.js` — Electron main process, wires up IPC handlers.
- `src/preload.js` — secure bridge exposing a minimal `window.api` to the UI.
- `src/renderer/` — the actual UI (HTML/CSS/JS, no framework needed for MVP).

## Setup

You'll need [Node.js](https://nodejs.org) installed (LTS version is fine).

```bash
cd smart-installer
npm install
npm start
```

This opens the Electron window. Try typing "pdf editor" or "video player" in the
Find & Install tab.

## Important notes before you extend this

1. **Only official URLs.** Every entry in `apps.json` should point straight to the
   vendor's real download link. Never have the app fetch installers from anywhere
   the "AI" freely decides — that's how you'd end up distributing malware by accident.
2. **UAC prompts are expected.** Many installers need admin rights on Windows —
   don't try to silently bypass that, it's a legitimate OS security gate.
3. **Verify URLs periodically.** Vendors change their download URLs sometimes
   (versions in the path, CDN changes). A few entries in `apps.json` use "latest"
   style URLs that are more stable, but double check before demoing.
4. **This does NOT verify file integrity yet.** A production version should check
   SHA256 checksums against known-good values before running any installer.

## Next steps (roadmap)

- [ ] Expand `apps.json` to 30+ apps
- [ ] Add checksum verification before running installers
- [ ] Add install history (persist to a local JSON/SQLite file)
- [ ] Add uninstall detection (don't suggest installing something already installed)
- [ ] Replace matcher.js with an LLM API call for true natural-language understanding
- [ ] Package with `electron-builder` into a distributable .exe (`npm run build`)
- [ ] Add auto-update checking for the catalog itself (fetch apps.json from a server
      instead of shipping it statically)

## Building a distributable .exe

```bash
npm run build
```

This uses `electron-builder` (already in devDependencies) to produce an installer
in a `dist/` folder, using the config already set in `package.json`.
