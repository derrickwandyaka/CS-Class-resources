const { app, BrowserWindow, ipcMain } = require("electron");
const path = require("path");
const fs = require("fs");

const { findMatches } = require("./matcher");
const {
  installFromCatalogEntry,
  scanForOfflineInstallers,
  runInstaller,
} = require("./installer");

const CATALOG_PATH = path.join(__dirname, "..", "catalog", "apps.json");

function loadCatalog() {
  const raw = fs.readFileSync(CATALOG_PATH, "utf-8");
  return JSON.parse(raw);
}

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 900,
    height: 650,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  mainWindow.loadFile(path.join(__dirname, "renderer", "index.html"));
}

app.whenReady().then(() => {
  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

// ---- IPC handlers: renderer calls these via window.api.* (see preload.js) ----

ipcMain.handle("search-catalog", (event, query) => {
  const catalog = loadCatalog();
  return findMatches(query, catalog, 5);
});

ipcMain.handle("install-online", async (event, entryId) => {
  const catalog = loadCatalog();
  const entry = catalog.find((e) => e.id === entryId);
  if (!entry) throw new Error("App not found in catalog");

  return installFromCatalogEntry(entry, (progress) => {
    // Push progress updates back to the renderer in real time
    event.sender.send("install-progress", progress);
  });
});

ipcMain.handle("scan-offline", () => {
  const catalog = loadCatalog();
  return scanForOfflineInstallers(catalog);
});

ipcMain.handle("install-offline-file", async (event, { filePath, silentArgs }) => {
  return runInstaller(filePath, silentArgs);
});
