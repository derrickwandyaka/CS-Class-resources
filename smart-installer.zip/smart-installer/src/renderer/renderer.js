// ---- Mode switching ----
const modeButtons = document.querySelectorAll(".mode-btn");
const panels = {
  online: document.getElementById("online-panel"),
  offline: document.getElementById("offline-panel"),
};

modeButtons.forEach((btn) => {
  btn.addEventListener("click", () => {
    modeButtons.forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    Object.values(panels).forEach((p) => p.classList.remove("active"));
    panels[btn.dataset.mode].classList.add("active");
  });
});

// ---- Logging helper ----
const logList = document.getElementById("log-list");
function log(message, isError = false) {
  const li = document.createElement("li");
  li.className = "log-item" + (isError ? " error" : "");
  const time = new Date().toLocaleTimeString();
  li.textContent = `[${time}] ${message}`;
  logList.prepend(li);
}

// ---- Online: search + install ----
const searchInput = document.getElementById("search-input");
const searchBtn = document.getElementById("search-btn");
const resultsList = document.getElementById("results-list");

async function runSearch() {
  const query = searchInput.value.trim();
  if (!query) return;

  resultsList.innerHTML = "";
  log(`Searching for: "${query}"`);

  const matches = await window.api.searchCatalog(query);

  if (matches.length === 0) {
    resultsList.innerHTML = `<li class="empty-state">No matches found. Try different words.</li>`;
    return;
  }

  matches.forEach((entry) => {
    const li = document.createElement("li");
    li.className = "result-item";
    li.innerHTML = `
      <div class="result-info">
        <div class="result-name">${entry.name}</div>
        <div class="result-desc">${entry.description}</div>
      </div>
      <button class="install-btn" data-id="${entry.id}">Install</button>
    `;
    resultsList.appendChild(li);
  });
}

searchBtn.addEventListener("click", runSearch);
searchInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") runSearch();
});

resultsList.addEventListener("click", async (e) => {
  if (!e.target.classList.contains("install-btn")) return;
  const entryId = e.target.dataset.id;
  e.target.disabled = true;
  e.target.textContent = "Starting...";

  try {
    log(`Downloading and installing "${entryId}"...`);
    await window.api.installOnline(entryId);
    e.target.textContent = "Installed";
  } catch (err) {
    log(`Failed to install "${entryId}": ${err.message}`, true);
    e.target.textContent = "Failed";
    e.target.disabled = false;
  }
});

// Live progress updates pushed from main process
window.api.onInstallProgress((progress) => {
  if (progress.stage === "downloading") {
    log(`Downloading... ${progress.percent}%`);
  } else if (progress.stage === "installing") {
    log(`Running installer...`);
  } else if (progress.stage === "done") {
    log(`Install launched successfully.`);
  }
});

// ---- Offline: scan + install ----
const scanBtn = document.getElementById("scan-btn");
const offlineResultsList = document.getElementById("offline-results-list");

scanBtn.addEventListener("click", async () => {
  offlineResultsList.innerHTML = "";
  log("Scanning Downloads and Desktop for installers...");

  const found = await window.api.scanOffline();

  if (found.length === 0) {
    offlineResultsList.innerHTML = `<li class="empty-state">No matching installers found on disk.</li>`;
    return;
  }

  found.forEach(({ entry, filePath, fileName }) => {
    const li = document.createElement("li");
    li.className = "result-item";
    li.innerHTML = `
      <div class="result-info">
        <div class="result-name">${entry.name}</div>
        <div class="result-desc">${fileName}</div>
      </div>
      <button class="install-btn" data-path="${filePath}" data-args="${entry.silent_args}">Install</button>
    `;
    offlineResultsList.appendChild(li);
  });
});

offlineResultsList.addEventListener("click", async (e) => {
  if (!e.target.classList.contains("install-btn")) return;
  const filePath = e.target.dataset.path;
  const silentArgs = e.target.dataset.args;
  e.target.disabled = true;
  e.target.textContent = "Starting...";

  try {
    log(`Running installer: ${filePath}`);
    await window.api.installOfflineFile({ filePath, silentArgs });
    e.target.textContent = "Installed";
  } catch (err) {
    log(`Failed to run installer: ${err.message}`, true);
    e.target.textContent = "Failed";
    e.target.disabled = false;
  }
});
