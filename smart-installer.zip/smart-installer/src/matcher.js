/**
 * matcher.js
 * Very simple keyword-overlap matcher.
 * Later you can swap this out for an LLM call without touching the rest of the app -
 * just make findMatches() async and call an API instead.
 */

function normalize(str) {
  return str
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter(Boolean);
}

// Basic Levenshtein distance for typo tolerance (e.g. "fotoshop" -> "photoshop")
function levenshtein(a, b) {
  const dp = Array.from({ length: a.length + 1 }, (_, i) =>
    Array(b.length + 1).fill(0)
  );
  for (let i = 0; i <= a.length; i++) dp[i][0] = i;
  for (let j = 0; j <= b.length; j++) dp[0][j] = j;

  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      if (a[i - 1] === b[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1];
      } else {
        dp[i][j] = 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
      }
    }
  }
  return dp[a.length][b.length];
}

function wordsAreClose(w1, w2) {
  if (w1 === w2) return true;
  if (Math.abs(w1.length - w2.length) > 2) return false;
  const distance = levenshtein(w1, w2);
  // allow 1 typo for short words, 2 for longer words
  const threshold = w1.length > 5 ? 2 : 1;
  return distance <= threshold;
}

/**
 * Score a single catalog entry against the user's query words.
 */
function scoreEntry(entry, queryWords) {
  const entryWords = new Set();
  entry.keywords.forEach((kw) => normalize(kw).forEach((w) => entryWords.add(w)));
  normalize(entry.name).forEach((w) => entryWords.add(w));

  let score = 0;
  for (const qWord of queryWords) {
    for (const eWord of entryWords) {
      if (qWord === eWord) {
        score += 3; // exact match worth more
      } else if (wordsAreClose(qWord, eWord)) {
        score += 1; // fuzzy match worth less
      }
    }
  }
  return score;
}

/**
 * Returns catalog entries sorted by relevance to the query.
 * @param {string} query - raw user input, e.g. "i need to edit pdfs"
 * @param {Array} catalog - array of app entries from apps.json
 * @param {number} limit - max results to return
 */
function findMatches(query, catalog, limit = 5) {
  const queryWords = normalize(query);
  if (queryWords.length === 0) return [];

  const scored = catalog
    .map((entry) => ({ entry, score: scoreEntry(entry, queryWords) }))
    .filter((r) => r.score > 0)
    .sort((a, b) => b.score - a.score);

  return scored.slice(0, limit).map((r) => r.entry);
}

module.exports = { findMatches, normalize, levenshtein };
