/**
 * installer.js
 * Handles: downloading installers from official URLs, running them silently,
 * and scanning local folders for already-downloaded installers (offline mode).
 */

const https = require("https");
const fs = require("fs");
const path = require("path");
const os = require("os");
const { spawn } = require("child_process");

const TEMP_DIR = path.join(os.tmpdir(), "smart-installer-downloads");

function ensureTempDir() {
  if (!fs.existsSync(TEMP_DIR)) {
    fs.mkdirSync(TEMP_DIR, { recursive: true });
  }
}

/**
 * Downloads a file, following redirects, reporting progress via callback.
 */
function downloadFile(url, destPath, onProgress) {
  return new Promise((resolve, reject) => {
    const doRequest = (currentUrl, redirectCount = 0) => {
      if (redirectCount > 5) {
        reject(new Error("Too many redirects"));
        return;
      }

      https
        .get(currentUrl, (res) => {
          // Follow redirects (very common for vendor "latest" download links)
          if (
            res.statusCode >= 300 &&
            res.statusCode < 400 &&
            res.headers.location
          ) {
            doRequest(res.headers.location, redirectCount + 1);
            return;
          }

          if (res.statusCode !== 200) {
            reject(new Error(`Download failed with status ${res.statusCode}`));
            return;
          }

          const totalBytes = parseInt(res.headers["content-length"] || "0", 10);
          let downloadedBytes = 0;

          const fileStream = fs.createWriteStream(destPath);
          res.on("data", (chunk) => {
            downloadedBytes += chunk.length;
            if (onProgress && totalBytes > 0) {
              onProgress(Math.round((downloadedBytes / totalBytes) * 100));
            }
          });

          res.pipe(fileStream);
          fileStream.on("finish", () => {
            fileStream.close(() => resolve(destPath));
          });
          fileStream.on("error", reject);
        })
        .on("error", reject);
    };

    doRequest(url);
  });
}

/**
 * Runs an installer executable with silent-install flags.
 * NOTE: on Windows this will trigger a UAC prompt if the installer needs admin rights -
 * that's expected and correct; don't try to suppress it.
 */
function runInstaller(installerPath, silentArgs) {
  return new Promise((resolve, reject) => {
    const args = (silentArgs || "").split(" ").filter(Boolean);
    const child = spawn(installerPath, args, {
      detached: true,
      stdio: "ignore",
    });

    child.on("error", reject);

    // Installers often spawn their own child process and exit immediately,
    // so we resolve on spawn rather than waiting for 'exit' in many cases.
    // For a more robust v2, track the actual install completion via the
    // installer's own exit code where possible.
    child.unref();
    resolve({ started: true, pid: child.pid });
  });
}

/**
 * Full online install flow: download + run.
 */
async function installFromCatalogEntry(entry, onProgress) {
  ensureTempDir();
  const destPath = path.join(TEMP_DIR, `${entry.id}-installer.exe`);

  onProgress && onProgress({ stage: "downloading", percent: 0 });
  await downloadFile(entry.official_url, destPath, (percent) => {
    onProgress && onProgress({ stage: "downloading", percent });
  });

  onProgress && onProgress({ stage: "installing", percent: 100 });
  const result = await runInstaller(destPath, entry.silent_args);

  onProgress && onProgress({ stage: "done", percent: 100 });
  return { ...result, installerPath: destPath };
}

/**
 * Offline mode: scan common folders for installer files that match
 * a catalog entry's filename_hints.
 */
function scanForOfflineInstallers(catalog, extraFolders = []) {
  const foldersToScan = [
    path.join(os.homedir(), "Downloads"),
    path.join(os.homedir(), "Desktop"),
    ...extraFolders,
  ].filter((f) => fs.existsSync(f));

  const found = [];

  for (const folder of foldersToScan) {
    let files;
    try {
      files = fs.readdirSync(folder);
    } catch {
      continue;
    }

    for (const file of files) {
      const lowerFile = file.toLowerCase();
      const ext = path.extname(lowerFile);
      if (![".exe", ".msi"].includes(ext)) continue;

      for (const entry of catalog) {
        const isMatch = entry.filename_hints.some((hint) =>
          lowerFile.includes(hint.toLowerCase())
        );
        if (isMatch) {
          found.push({
            entry,
            filePath: path.join(folder, file),
            fileName: file,
          });
        }
      }
    }
  }

  return found;
}

module.exports = {
  downloadFile,
  runInstaller,
  installFromCatalogEntry,
  scanForOfflineInstallers,
};
