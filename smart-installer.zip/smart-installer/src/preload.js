const { contextBridge, ipcRenderer } = require("electron");

// Expose a small, safe API to the renderer instead of full Node access.
// This is the correct security pattern for Electron - never set
// nodeIntegration: true and skip this file.
contextBridge.exposeInMainWorld("api", {
  searchCatalog: (query) => ipcRenderer.invoke("search-catalog", query),
  installOnline: (entryId) => ipcRenderer.invoke("install-online", entryId),
  scanOffline: () => ipcRenderer.invoke("scan-offline"),
  installOfflineFile: (payload) =>
    ipcRenderer.invoke("install-offline-file", payload),
  onInstallProgress: (callback) =>
    ipcRenderer.on("install-progress", (event, progress) => callback(progress)),
});
